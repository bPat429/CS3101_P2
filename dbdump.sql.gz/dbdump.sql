-- MySQL dump 10.19  Distrib 10.3.28-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: bp50_cs3101_p2_db
-- ------------------------------------------------------
-- Server version	10.3.28-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `court`
--

DROP TABLE IF EXISTS `court`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `court` (
  `number` int(11) NOT NULL,
  `venue_name` varchar(256) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`number`,`venue_name`),
  KEY `court_venue_name_fk` (`venue_name`),
  CONSTRAINT `court_venue_name_fk` FOREIGN KEY (`venue_name`) REFERENCES `venue` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `court`
--

LOCK TABLES `court` WRITE;
/*!40000 ALTER TABLE `court` DISABLE KEYS */;
INSERT INTO `court` VALUES (1,'East Sands Leisure Centre'),(1,'Forthill Squash Club'),(1,'University Sports Centre'),(1,'Waterstone Crook Sports Centre'),(2,'East Sands Leisure Centre'),(2,'Forthill Squash Club'),(2,'University Sports Centre'),(2,'Waterstone Crook Sports Centre'),(3,'University Sports Centre'),(3,'Waterstone Crook Sports Centre'),(4,'Waterstone Crook Sports Centre');
/*!40000 ALTER TABLE `court` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `league`
--

DROP TABLE IF EXISTS `league`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `league` (
  `name` varchar(256) COLLATE utf8_bin NOT NULL,
  `year` int(11) NOT NULL,
  `prize_money` decimal(12,2) DEFAULT 0.00,
  `winner_email` varchar(256) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`name`,`year`),
  UNIQUE KEY `league_name_year_unique` (`name`,`year`),
  KEY `year` (`year`),
  KEY `winner_email_fk` (`winner_email`),
  CONSTRAINT `winner_email_fk` FOREIGN KEY (`winner_email`) REFERENCES `player` (`email`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `league`
--

LOCK TABLES `league` WRITE;
/*!40000 ALTER TABLE `league` DISABLE KEYS */;
INSERT INTO `league` VALUES ('Alexander McLintoch trophy',2018,250.00,'louis.payne@gmail.com'),('Alexander McLintoch trophy',2019,100.00,'tabitha.stacey@gmail.com'),('Alexander McLintoch trophy',2020,300.00,'sylvia.hathaway@gmail.com'),('Oldies cup',2018,50.00,'srrogers@yahoo.co.uk'),('Oldies cup',2019,50.00,'srrogers@yahoo.co.uk'),('Oldies cup',2020,0.00,'u_marsden@gmail.com');
/*!40000 ALTER TABLE `league` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `league_player`
--

DROP TABLE IF EXISTS `league_player`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `league_player` (
  `email` varchar(256) COLLATE utf8_bin NOT NULL,
  `league_name` varchar(256) COLLATE utf8_bin NOT NULL,
  `league_year` int(11) NOT NULL,
  PRIMARY KEY (`email`,`league_name`,`league_year`),
  KEY `league_player_league_name_fk` (`league_name`),
  KEY `league_player_league_year_fk` (`league_year`),
  CONSTRAINT `league_player_email_fk` FOREIGN KEY (`email`) REFERENCES `player` (`email`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `league_player_league_name_fk` FOREIGN KEY (`league_name`) REFERENCES `league` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `league_player_league_year_fk` FOREIGN KEY (`league_year`) REFERENCES `league` (`year`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `league_player`
--

LOCK TABLES `league_player` WRITE;
/*!40000 ALTER TABLE `league_player` DISABLE KEYS */;
INSERT INTO `league_player` VALUES ('butch@xyz.club','Alexander McLintoch trophy',2019),('butch@xyz.club','Alexander McLintoch trophy',2020),('final_fantasy_freak1993@hotmail.com','Alexander McLintoch trophy',2018),('final_fantasy_freak1993@hotmail.com','Alexander McLintoch trophy',2019),('gary_the_man@yahoo.co.uk','Alexander McLintoch trophy',2019),('gary_the_man@yahoo.co.uk','Alexander McLintoch trophy',2020),('gary_the_man@yahoo.co.uk','Oldies cup',2018),('gary_the_man@yahoo.co.uk','Oldies cup',2019),('gary_the_man@yahoo.co.uk','Oldies cup',2020),('jwh@hotmail.com','Alexander McLintoch trophy',2018),('jwh@hotmail.com','Alexander McLintoch trophy',2019),('louis.payne@gmail.com','Alexander McLintoch trophy',2018),('srrogers@yahoo.co.uk','Oldies cup',2018),('srrogers@yahoo.co.uk','Oldies cup',2019),('sylvia.hathaway@gmail.com','Alexander McLintoch trophy',2018),('sylvia.hathaway@gmail.com','Alexander McLintoch trophy',2019),('sylvia.hathaway@gmail.com','Alexander McLintoch trophy',2020),('tabitha.stacey@gmail.com','Alexander McLintoch trophy',2018),('tabitha.stacey@gmail.com','Alexander McLintoch trophy',2019),('tabitha.stacey@gmail.com','Alexander McLintoch trophy',2020),('tasha.marsden@gmail.com','Oldies cup',2018),('tasha.marsden@gmail.com','Oldies cup',2019),('tasha.marsden@gmail.com','Oldies cup',2020),('u_marsden@gmail.com','Oldies cup',2018),('u_marsden@gmail.com','Oldies cup',2019),('u_marsden@gmail.com','Oldies cup',2020);
/*!40000 ALTER TABLE `league_player` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `played_match`
--

DROP TABLE IF EXISTS `played_match`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `played_match` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `p1_email` varchar(256) COLLATE utf8_bin NOT NULL,
  `p2_email` varchar(256) COLLATE utf8_bin NOT NULL,
  `p1_games_won` int(11) DEFAULT 0,
  `p2_games_won` int(11) DEFAULT 0,
  `date_played` date NOT NULL,
  `court_number` int(11) NOT NULL,
  `venue_name` varchar(256) COLLATE utf8_bin NOT NULL,
  `league_name` varchar(256) COLLATE utf8_bin NOT NULL,
  `league_year` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `p1_email_fk` (`p1_email`),
  KEY `p2_email_fk` (`p2_email`),
  KEY `court_number_fk` (`court_number`),
  KEY `venue_name_fk` (`venue_name`),
  KEY `league_name_fk` (`league_name`),
  KEY `league_year_fk` (`league_year`),
  CONSTRAINT `court_number_fk` FOREIGN KEY (`court_number`) REFERENCES `court` (`number`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `league_name_fk` FOREIGN KEY (`league_name`) REFERENCES `league` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `league_year_fk` FOREIGN KEY (`league_year`) REFERENCES `league` (`year`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `p1_email_fk` FOREIGN KEY (`p1_email`) REFERENCES `player` (`email`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `p2_email_fk` FOREIGN KEY (`p2_email`) REFERENCES `player` (`email`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `venue_name_fk` FOREIGN KEY (`venue_name`) REFERENCES `venue` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `match_wins_check` CHECK ((3 = `p1_games_won` or 3 = `p2_games_won`) and (3 > `p1_games_won` or 3 > `p2_games_won`)),
  CONSTRAINT `match_year_check` CHECK (year(`date_played`) = `league_year`),
  CONSTRAINT `different_players_check` CHECK (`p1_email` <> `p2_email`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `played_match`
--

LOCK TABLES `played_match` WRITE;
/*!40000 ALTER TABLE `played_match` DISABLE KEYS */;
INSERT INTO `played_match` VALUES (20,'gary_the_man@yahoo.co.uk','tasha.marsden@gmail.com',0,3,'2018-11-04',4,'Waterstone Crook Sports Centre','Oldies cup',2018),(25,'gary_the_man@yahoo.co.uk','tasha.marsden@gmail.com',2,3,'2019-09-29',4,'Waterstone Crook Sports Centre','Oldies cup',2019),(28,'gary_the_man@yahoo.co.uk','u_marsden@gmail.com',3,1,'2019-10-30',3,'University Sports Centre','Oldies cup',2019),(33,'louis.payne@gmail.com','final_fantasy_freak1993@hotmail.com',3,0,'2018-04-11',3,'University Sports Centre','Alexander McLintoch trophy',2018),(35,'louis.payne@gmail.com','jwh@hotmail.com',3,0,'2018-05-07',3,'University Sports Centre','Alexander McLintoch trophy',2018),(41,'sylvia.hathaway@gmail.com','louis.payne@gmail.com',2,3,'2018-07-09',3,'University Sports Centre','Alexander McLintoch trophy',2018),(44,'sylvia.hathaway@gmail.com','butch@xyz.club',0,3,'2019-04-16',3,'University Sports Centre','Alexander McLintoch trophy',2019),(48,'sylvia.hathaway@gmail.com','final_fantasy_freak1993@hotmail.com',1,3,'2019-05-03',4,'Waterstone Crook Sports Centre','Alexander McLintoch trophy',2019),(49,'tabitha.stacey@gmail.com','final_fantasy_freak1993@hotmail.com',3,0,'2019-05-13',3,'University Sports Centre','Alexander McLintoch trophy',2019),(50,'jwh@hotmail.com','final_fantasy_freak1993@hotmail.com',1,3,'2019-05-21',3,'University Sports Centre','Alexander McLintoch trophy',2019),(51,'gary_the_man@yahoo.co.uk','sylvia.hathaway@gmail.com',1,3,'2019-06-06',4,'Waterstone Crook Sports Centre','Alexander McLintoch trophy',2019),(62,'butch@xyz.club','gary_the_man@yahoo.co.uk',3,2,'2020-07-06',3,'University Sports Centre','Alexander McLintoch trophy',2020);
/*!40000 ALTER TABLE `played_match` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`bp50`@`%`*/ /*!50003 trigger players_registered_insert_trigger before insert on played_match for each row
begin
    if (new.p1_email not in (select email
                             from league_player as p
                             where p.league_year = new.league_year
                               AND p.league_name = new.league_name))
    then
        signal sqlstate '45001' set message_text = 'Invalid match, player 1 not registered in league';
    end if;
    if (new.p2_email not in (select email
                             from league_player as p
                             where p.league_year = new.league_year
                               AND p.league_name = new.league_name))
    then
        signal sqlstate '45001' set message_text = 'Invalid match, player 2 not registered in league';
    end if;
end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`bp50`@`%`*/ /*!50003 trigger players_registered_update_trigger before update on played_match for each row
begin
    if (new.p1_email not in (select email
                             from league_player as p
                             where p.league_year = new.league_year
                               AND p.league_name = new.league_name))
    then
        signal sqlstate '45001' set message_text = 'Invalid match, player 1 not registered in league';
    end if;
    if (new.p2_email not in (select email
                             from league_player as p
                             where p.league_year = new.league_year
                               AND p.league_name = new.league_name))
    then
        signal sqlstate '45001' set message_text = 'Invalid match, player 2 not registered in league';
    end if;
end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `player`
--

DROP TABLE IF EXISTS `player`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player` (
  `email` varchar(256) COLLATE utf8_bin NOT NULL,
  `forename` varchar(256) COLLATE utf8_bin NOT NULL,
  `middlenames` varchar(256) COLLATE utf8_bin DEFAULT NULL,
  `surname` varchar(256) COLLATE utf8_bin NOT NULL,
  `date_of_birth` date NOT NULL,
  PRIMARY KEY (`email`),
  CONSTRAINT `email_at_check` CHECK (1 < locate('@',`email`) and locate('@',`email`) < char_length(`email`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player`
--

LOCK TABLES `player` WRITE;
/*!40000 ALTER TABLE `player` DISABLE KEYS */;
INSERT INTO `player` VALUES ('butch@xyz.club','Jamie','Eugene Korey','Butcher','1985-09-21'),('final_fantasy_freak1993@hotmail.com','Kirsten','Aileen Louise','Jackman','1993-10-28'),('gary_the_man@yahoo.co.uk','Gary','Carl','Marsden','1985-10-12'),('jwh@hotmail.com','Jeremy','Wardell','Huddleston','1991-02-13'),('leighton.buzzard@gmail.com','Leighton','Alan','Buzzard','1980-05-17'),('louis.payne@gmail.com','Louis','Kennard','Payne','2000-05-31'),('mad_maddy@gmail.com','Madeleine',NULL,'Daubney','1991-03-08'),('srrogers@yahoo.co.uk','Sue','Rosemary','Rogers','1965-07-30'),('sylvia.hathaway@gmail.com','Sylvia','Loraine','Hathaway','2004-01-02'),('tabitha.stacey@gmail.com','Tabitha',NULL,'Stacey','2005-09-10'),('tasha.marsden@gmail.com','Natasha','Joy Bernardette Louise','Marsden','1960-04-28'),('u_marsden@gmail.com','Ulysses',NULL,'Marsden','1977-05-07');
/*!40000 ALTER TABLE `player` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `player_phone`
--

DROP TABLE IF EXISTS `player_phone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_phone` (
  `email` varchar(256) COLLATE utf8_bin NOT NULL,
  `phone_number` varchar(256) COLLATE utf8_bin NOT NULL,
  `phone_type` enum('home','mobile','work') COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`email`,`phone_number`),
  CONSTRAINT `player_email_fk` FOREIGN KEY (`email`) REFERENCES `player` (`email`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `phone_type_check` CHECK (`phone_type` in ('home','mobile','work'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `player_phone`
--

LOCK TABLES `player_phone` WRITE;
/*!40000 ALTER TABLE `player_phone` DISABLE KEYS */;
INSERT INTO `player_phone` VALUES ('butch@xyz.club','079 6943 8448','mobile'),('final_fantasy_freak1993@hotmail.com','07700 900909','mobile'),('gary_the_man@yahoo.co.uk','0151 496 0777','home'),('jwh@hotmail.com','0131 496 0470','home'),('leighton.buzzard@gmail.com','0117 496 0714','home'),('leighton.buzzard@gmail.com','0131 496 0962','work'),('louis.payne@gmail.com','07700 900654','mobile'),('mad_maddy@gmail.com','0115 496 0961','work'),('mad_maddy@gmail.com','020 7946 0501','home'),('srrogers@yahoo.co.uk','07700 900949','mobile'),('sylvia.hathaway@gmail.com','07700 900939','mobile'),('tabitha.stacey@gmail.com','07837 585417','mobile'),('tasha.marsden@gmail.com','078 8934 4229','mobile'),('u_marsden@gmail.com','0131 496 0745','home');
/*!40000 ALTER TABLE `player_phone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `venue`
--

DROP TABLE IF EXISTS `venue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `venue` (
  `name` varchar(256) COLLATE utf8_bin NOT NULL,
  `address` varchar(256) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `venue`
--

LOCK TABLES `venue` WRITE;
/*!40000 ALTER TABLE `venue` DISABLE KEYS */;
INSERT INTO `venue` VALUES ('East Sands Leisure Centre','2 St Mary St, St Andrews KY16 8LH'),('Forthill Squash Club','20 Forthill Road, Broughty Ferry, Dundee DD5 3SR'),('University Sports Centre','9 St Leonard’s Rd, St Andrews KY16 9DY'),('Waterstone Crook Sports Centre','69 Kirk Rd, Newport-on-Tay DD6 8HY');
/*!40000 ALTER TABLE `venue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `view_all_won_matches`
--

DROP TABLE IF EXISTS `view_all_won_matches`;
/*!50001 DROP VIEW IF EXISTS `view_all_won_matches`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_all_won_matches` (
  `email` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_contact_details`
--

DROP TABLE IF EXISTS `view_contact_details`;
/*!50001 DROP VIEW IF EXISTS `view_contact_details`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_contact_details` (
  `fullname` tinyint NOT NULL,
  `email` tinyint NOT NULL,
  `phone_numbers` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_court_details`
--

DROP TABLE IF EXISTS `view_court_details`;
/*!50001 DROP VIEW IF EXISTS `view_court_details`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_court_details` (
  `number` tinyint NOT NULL,
  `venue_name` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `address` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_matches_with_fullname`
--

DROP TABLE IF EXISTS `view_matches_with_fullname`;
/*!50001 DROP VIEW IF EXISTS `view_matches_with_fullname`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_matches_with_fullname` (
  `p2_name` tinyint NOT NULL,
  `p1_name` tinyint NOT NULL,
  `p1_games_won` tinyint NOT NULL,
  `p2_games_won` tinyint NOT NULL,
  `date_played` tinyint NOT NULL,
  `court_number` tinyint NOT NULL,
  `venue_name` tinyint NOT NULL,
  `league_name` tinyint NOT NULL,
  `league_year` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_matches_with_p1_fullname`
--

DROP TABLE IF EXISTS `view_matches_with_p1_fullname`;
/*!50001 DROP VIEW IF EXISTS `view_matches_with_p1_fullname`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_matches_with_p1_fullname` (
  `p1_name` tinyint NOT NULL,
  `p2_email` tinyint NOT NULL,
  `p1_games_won` tinyint NOT NULL,
  `p2_games_won` tinyint NOT NULL,
  `date_played` tinyint NOT NULL,
  `court_number` tinyint NOT NULL,
  `venue_name` tinyint NOT NULL,
  `league_name` tinyint NOT NULL,
  `league_year` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_never_played`
--

DROP TABLE IF EXISTS `view_never_played`;
/*!50001 DROP VIEW IF EXISTS `view_never_played`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_never_played` (
  `number` tinyint NOT NULL,
  `venue_name` tinyint NOT NULL,
  `address` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_player_fullname`
--

DROP TABLE IF EXISTS `view_player_fullname`;
/*!50001 DROP VIEW IF EXISTS `view_player_fullname`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_player_fullname` (
  `email` tinyint NOT NULL,
  `surname` tinyint NOT NULL,
  `fullname` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_player_phones`
--

DROP TABLE IF EXISTS `view_player_phones`;
/*!50001 DROP VIEW IF EXISTS `view_player_phones`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_player_phones` (
  `email` tinyint NOT NULL,
  `phone_numbers` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_win_count`
--

DROP TABLE IF EXISTS `view_win_count`;
/*!50001 DROP VIEW IF EXISTS `view_win_count`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_win_count` (
  `email` tinyint NOT NULL,
  `matches_won` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `view_all_won_matches`
--

/*!50001 DROP TABLE IF EXISTS `view_all_won_matches`*/;
/*!50001 DROP VIEW IF EXISTS `view_all_won_matches`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`bp50`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_all_won_matches` AS select `played_match`.`p1_email` AS `email` from `played_match` where `played_match`.`p1_games_won` = 3 union all select `played_match`.`p2_email` AS `email` from `played_match` where `played_match`.`p2_games_won` = 3 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_contact_details`
--

/*!50001 DROP TABLE IF EXISTS `view_contact_details`*/;
/*!50001 DROP VIEW IF EXISTS `view_contact_details`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`bp50`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_contact_details` AS select `f`.`fullname` AS `fullname`,`f`.`email` AS `email`,`p`.`phone_numbers` AS `phone_numbers` from (`view_player_fullname` `f` join `view_player_phones` `p`) where `f`.`email` = `p`.`email` order by `f`.`surname`,`f`.`fullname`,`f`.`email` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_court_details`
--

/*!50001 DROP TABLE IF EXISTS `view_court_details`*/;
/*!50001 DROP VIEW IF EXISTS `view_court_details`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`bp50`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_court_details` AS select `court`.`number` AS `number`,`court`.`venue_name` AS `venue_name`,`venue`.`name` AS `name`,`venue`.`address` AS `address` from (`court` join `venue` on(`court`.`venue_name` = `venue`.`name`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_matches_with_fullname`
--

/*!50001 DROP TABLE IF EXISTS `view_matches_with_fullname`*/;
/*!50001 DROP VIEW IF EXISTS `view_matches_with_fullname`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`bp50`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_matches_with_fullname` AS select `f`.`fullname` AS `p2_name`,`m`.`p1_name` AS `p1_name`,`m`.`p1_games_won` AS `p1_games_won`,`m`.`p2_games_won` AS `p2_games_won`,`m`.`date_played` AS `date_played`,`m`.`court_number` AS `court_number`,`m`.`venue_name` AS `venue_name`,`m`.`league_name` AS `league_name`,`m`.`league_year` AS `league_year` from (`view_player_fullname` `f` join `view_matches_with_p1_fullname` `m`) where `f`.`email` = `m`.`p2_email` order by `m`.`venue_name` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_matches_with_p1_fullname`
--

/*!50001 DROP TABLE IF EXISTS `view_matches_with_p1_fullname`*/;
/*!50001 DROP VIEW IF EXISTS `view_matches_with_p1_fullname`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`bp50`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_matches_with_p1_fullname` AS select `f`.`fullname` AS `p1_name`,`m`.`p2_email` AS `p2_email`,`m`.`p1_games_won` AS `p1_games_won`,`m`.`p2_games_won` AS `p2_games_won`,`m`.`date_played` AS `date_played`,`m`.`court_number` AS `court_number`,`m`.`venue_name` AS `venue_name`,`m`.`league_name` AS `league_name`,`m`.`league_year` AS `league_year` from (`view_player_fullname` `f` join `played_match` `m`) where `f`.`email` = `m`.`p1_email` order by `m`.`venue_name` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_never_played`
--

/*!50001 DROP TABLE IF EXISTS `view_never_played`*/;
/*!50001 DROP VIEW IF EXISTS `view_never_played`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`bp50`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_never_played` AS select distinct `view_court_details`.`number` AS `number`,`view_court_details`.`venue_name` AS `venue_name`,`view_court_details`.`address` AS `address` from (`view_court_details` join `played_match`) where !(`view_court_details`.`number` in (select distinct `played_match`.`court_number` from `played_match` where `view_court_details`.`venue_name` = `played_match`.`venue_name`)) order by `view_court_details`.`venue_name` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_player_fullname`
--

/*!50001 DROP TABLE IF EXISTS `view_player_fullname`*/;
/*!50001 DROP VIEW IF EXISTS `view_player_fullname`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`bp50`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_player_fullname` AS select `player`.`email` AS `email`,`player`.`surname` AS `surname`,concat_ws(' ',`player`.`forename`,`player`.`middlenames`,`player`.`surname`) AS `fullname` from `player` order by `player`.`email` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_player_phones`
--

/*!50001 DROP TABLE IF EXISTS `view_player_phones`*/;
/*!50001 DROP VIEW IF EXISTS `view_player_phones`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`bp50`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_player_phones` AS select `player_phone`.`email` AS `email`,group_concat(`player_phone`.`phone_number` separator ',') AS `phone_numbers` from `player_phone` group by `player_phone`.`email` order by `player_phone`.`email` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_win_count`
--

/*!50001 DROP TABLE IF EXISTS `view_win_count`*/;
/*!50001 DROP VIEW IF EXISTS `view_win_count`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`bp50`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `view_win_count` AS select distinct `view_all_won_matches`.`email` AS `email`,count(`view_all_won_matches`.`email`) over ( partition by `view_all_won_matches`.`email`) AS `matches_won` from `view_all_won_matches` order by `view_all_won_matches`.`email` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-04-21 18:17:00
